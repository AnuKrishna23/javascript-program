// DOM: Mini Project

// Develop the following application, use the following HTML elements to get started with. You will get the same code on starter folder. Apply all the styles and functionality using JavaScript only.

// 1. The year color is changing every 1 second
// 2. The date and time background color is changing every on seconds
// 3. Completed challenge has background green
// 4. Ongoing challenge has background yellow
// 5. Coming challenges have background red



// <!-- index.html -->


// <!DOCTYPE html>
// <html lang="en">
//   <head>
//     <title>JavaScript for Everyone:DOM</title>
//   </head>
//   <body>
//     <div class="wrapper">
//         <h1>JavaScript Challenges in 2024</h1>
//         <h2>30DaysOfJavaScript Challenge</h2>
//         <ul>
//             <li>30DaysOfPython Challenge Done</li>
//             <li>30DaysOfJavaScript Challenge Ongoing</li>
//             <li>30DaysOfReact Challenge Coming</li>
//             <li>30DaysOfFullStack Challenge Coming</li>
//             <li>30DaysOfDataAnalysis Challenge Coming</li>
//             <li>30DaysOfReactNative Challenge Coming</li>
//             <li>30DaysOfMachineLearning Challenge Coming</li>
//         </ul>
//     </div>
//   </body>
// </html>


//answer//
const yearElement = document.querySelector('h1');
const dateAndTimeElement = document.querySelector('h2');
const listItems = document.querySelectorAll('li');
function getRandomColor() {
  const letters = '0123456789ABCDEF';
  let color = '#';
  for (let i = 0; i < 6; i++) {
    color += letters[Math.floor(Math.random() * 16)];
  }
  return color;
}
function updateYearColor() {
  yearElement.style.color = getRandomColor();
}
function updateDateAndTimeBackgroundColor() {
  dateAndTimeElement.style.backgroundColor = getRandomColor();
}
function updateListItemBackgroundColors() {
  listItems.forEach((item) => {
    if (item.textContent.includes('Done')) {
      item.style.backgroundColor = 'green';
    } else if (item.textContent.includes('Ongoing')) {
      item.style.backgroundColor = 'yellow';
    } else {
      item.style.backgroundColor = 'red';
    }
  });
}
updateYearColor();
updateDateAndTimeBackgroundColor();
updateListItemBackgroundColors();
setInterval(() => {
  updateYearColor();
  updateDateAndTimeBackgroundColor();
}1000);