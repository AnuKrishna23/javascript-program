// Variables vary

var score;
score = 100;
console.log(score);

score = 150;
console.log(score);



/* Further Adventures
 *
 * 1) Change the value assigned to score.
 *    Run the program again.
 *
 * 2) Declare a second variable, maybe score2.
 *
 * 3) Assign your variable a value.
 *
 * 4) Use console.log to display your
 *    variable on the console.
 *
 * 5) Add a new line of code to alter the
 *    value of your variable after it
 *    has been displayed on the console.
 *
 * 6) Add a new line of code to display
 *    the new value of your variable.
 *
 */

//answer//
var score;
score = 100;
console.log(score);
score = 150;
console.log(score);
var score2;
score2 = 200;
console.log(score2);
score2 = 250;
console.log(score2);