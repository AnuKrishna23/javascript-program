// Using a variable

var score;
score = 100;
console.log(score);



/* Further Adventures
 *
 * 1) Change the value assigned to score.
 *    Run the program again.
 *
 * 2) Declare a second variable, maybe score2.
 *
 * 3) Assign your variable a value.
 *
 * 4) Use console.log to display your variable on the console.
 *
 */


//answer//
//Change the value assigned to score.Run the program again.//
var score;
score = 200;
console.log(score);

//Declare a second variable, maybe score2//
var score;
score = 200;
console.log(score);
var score2;

// Assign your variable a value//
var score;
score = 200;
console.log(score);
var score2;
score2 = 300;

// Use console.log to display your variable on the console//
var score;
score = 200;
console.log(score);
var score2;
score2 = 300;
console.log(score2);