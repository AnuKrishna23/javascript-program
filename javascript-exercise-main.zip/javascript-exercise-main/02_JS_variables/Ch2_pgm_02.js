// Assigning a value to a variable

var score;
score = 100;

/* Further Adventures
 *
 * 1) Click Run on the JS Bin Console panel.
 *    Nothing will be displayed on the console
 *    but the program will have run,
 *    creating the score variable.
 *
 * 2) Click in the console, just to the right of the blue prompt >
 *    The console should be highlighted and
 *    a cursor should be blinking next to the prompt.
 *
 * 3) Type the word score to match your variable name
 *    and press enter.
 *    100, the value assigned to score, should be displayed.
 *
 * 4) Change the value of score in the code above.
 *    Repeat steps 1, 2 and 3.
 *
 */

//answer//

var score;
score = 200;
