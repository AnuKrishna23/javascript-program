// Callbacks

const doSomething = callback => {
    setTimeout(() => {
      const skills = ['HTML', 'CSS', 'JS']
      callback('It did not go well', skills)
    }, 2000)
  }
  
  const callback = (err, result) => {
    if (err) {
      return console.log(err)
    }
    return console.log(result)
  }
  
  doSomething(callback);


// after 2 seconds it will print
// It did not go well

//answer//
const call (back) = (err, result) => {
  if (!err){
    return console.log(result)
  }
  return console.log(err)
}