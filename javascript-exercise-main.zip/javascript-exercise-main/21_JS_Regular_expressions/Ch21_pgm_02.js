// Write a function called tenMostFrequentWords which get the ten most frequent word from a string?

paragraph = `I love teaching. If you do not love teaching what else can you love. I love Python if you do not love something which can give you all the capabilities to develop an application what else can you love.`
console.log(tenMostFrequentWords(paragraph))

[
    {word:'love', count:6},
    {word:'you', count:5},
    {word:'can', count:3},
    {word:'what', count:2},
    {word:'teaching', count:2},
    {word:'not', count:2},
    {word:'else', count:2},
    {word:'do', count:2},
    {word:'I', count:2},
    {word:'which', count:1},
    {word:'to', count:1},
    {word:'the', count:1},
    {word:'something', count:1},
    {word:'if', count:1},
    {word:'give', count:1},
    {word:'develop',count:1},
    {word:'capabilities',count:1},
    {word:'application', count:1},
    {word:'an',count:1},
    {word:'all',count:1},
    {word:'Python',count:1},
    {word:'If',count:1}
]


console.log(tenMostFrequentWords(paragraph, 10))

[{word:'love', count:6},
    {word:'you', count:5},
    {word:'can', count:3},
    {word:'what', count:2},
    {word:'teaching', count:2},
    {word:'not', count:2},
    {word:'else', count:2},
    {word:'do', count:2},
    {word:'I', count:2},
    {word:'which', count:1}
    ]

    //answer//
    function tenMostFrequentWords(paragraph, n = 10) {
        let words = paragraph.toLowerCase().split(/\s+/);
        let frequencyMap = {};
        for (let word of words) {
           
            word = word.replace(/[^\w]/g, '');
            if (word) {
                frequencyMap[word] = frequencyMap[word] || 0;
                frequencyMap[word]++;
            }
        }
    
     
        let frequencyArray = Object.keys(frequencyMap).map(word => ({ word, count: frequencyMap[word] }));
    
        
        frequencyArray.sort((a, b) => b.count - a.count);

        return frequencyArray.slice(0, n);
    }
    
    paragraph = `I love teaching. If you do not love teaching what else can you love. I love Python if you do not love something which can give you all the capabilities to develop an application what else can you love.`
    
    console.log(tenMostFrequentWords(paragraph));
    
    console.log(tenMostFrequentWords(paragraph, 10));
    function isValidVariable(name) {
        var pattern = /^[a-zA-Z_$][a-zA-Z_$0-9]*$/;
        return pattern.test(name);
    }
    
    console.log(isValidVariable('first_name'));  // True
    console.log(isValidVariable('first-name')); // False
    console.log(isValidVariable('1first_name')); // False
    console.log(isValidVariable('firstname'));  // True